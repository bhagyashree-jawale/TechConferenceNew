package pkg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConvertService {
	Connection con;
    PreparedStatement stmt;
    ResultSet rs;
    ConvertService() throws ClassNotFoundException, SQLException
    {
        System.out.println("con1");
        Class.forName("org.h2.Driver"); 
        con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/tech", "sa",""); 
        System.out.println("con2");
    }
    ResultSet check(String firstc, String secondc) throws SQLException {
        System.out.println("service1");
       stmt=con.prepareStatement("select exchangevalue  from CountryCurrency where countryname1=? and countryname2=?");
       System.out.println(firstc);
       System.out.println(secondc);
       stmt.setString(1, firstc);
       stmt.setString(2, secondc);
        System.out.println("service2");
       rs=stmt.executeQuery();
        System.out.println("service3");
       return rs;
    }
}
