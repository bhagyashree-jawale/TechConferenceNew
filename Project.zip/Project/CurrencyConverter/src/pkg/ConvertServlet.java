package pkg;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ConvertServlet
 */
@WebServlet("/ConvertServlet")
public class ConvertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConvertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		try
		{
		PrintWriter out = response.getWriter();
            String firstc=request.getParameter("txtfirst");
            String secondc=request.getParameter("txtsecond");
            int amount=Integer.parseInt(request.getParameter("txtamount"));
            System.out.println("hello1");
            ConvertService cs=new ConvertService();
            ResultSet rs= cs.check(firstc,secondc);
            System.out.println("hello2");
            if(rs.next())
            {
                double examount=rs.getDouble("exchangevalue");
                double result=amount/examount;
   /*             RequestDispatcher rd=request.getRequestDispatcher("converter.jsp");
                rd.include(request, response);
                out.println("Resuld);
*/                
                out.println("<form action='ConvertServlet'> First Country  : <input type='text' name='txtfirst' value='' /><br><br>\r\n" + 
                		"            Second Country : <input type='text' name='txtsecond' value='' /><br><br>\r\n" + 
                		"            Amount         : <input type='text' name='txtamount' value='' /><br><br>\r\n" + 
                		"            <input type='submit' value='Convert' /><br><br>\r\n\n" + 
                		"           \r\nResult         : <input type='text' name="+result+ "  readonly='readonly' /></form>");

       
            }
            else
            {
                out.println("Data not found");
            }
		}
		catch (Exception e) {
			// TODO: handle exception
		}
        }
		

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
